#include "PreCompile.h"
#include "$fileinputname$Manager.h"
#include "$fileinputname$.h"

$fileinputname$Manager::$fileinputname$Manager() // default constructer ����Ʈ ������
{

}

$fileinputname$Manager::~$fileinputname$Manager() // default destructer ����Ʈ �Ҹ���
{
	for (const std::pair<std::string, $fileinputname$*>& Res : ResourcesMap)
	{
		if (nullptr != Res.second)
		{
			delete Res.second;
		}
	}

	ResourcesMap.clear();
}

$fileinputname$Manager::$fileinputname$Manager($fileinputname$Manager&& _other) noexcept  // default RValue Copy constructer ����Ʈ RValue ���������
{

}



$fileinputname$* $fileinputname$Manager::Create(const std::string& _Name)
{
	$fileinputname$* FindRes = Find(_Name);

	if (nullptr != FindRes)
	{
		GameEngineDebug::MsgBoxError(_Name + " Is Overlap Load");
	}


	$fileinputname$* NewRes = new $fileinputname$();
	NewRes->SetName(_Name);

	// �׸��� ���Ұų�?

	ResourcesMap.insert(std::map<std::string, $fileinputname$*>::value_type(_Name, NewRes));
	return NewRes;
}

$fileinputname$* $fileinputname$Manager::Load(const std::string& _Path)
{
	return Load(GameEnginePath::GetFileName(_Path), _Path);
}

$fileinputname$* $fileinputname$Manager::Load(const std::string& _Name, const std::string& _Path)
{
	$fileinputname$* FindRes = Find(_Name);

	if (nullptr != FindRes)
	{
		GameEngineDebug::MsgBoxError(_Name + " Is Overlap Load");
	}

	$fileinputname$* NewRes = new $fileinputname$();
	NewRes->SetName(_Name);


	ResourcesMap.insert(std::map<std::string, $fileinputname$*>::value_type(_Name, NewRes));
	return NewRes;
}

$fileinputname$* $fileinputname$Manager::Find(const std::string& _Name)
{
	std::map<std::string, $fileinputname$*>::iterator FindIter = ResourcesMap.find(_Name);

	if (FindIter != ResourcesMap.end())
	{
		return FindIter->second;
	}

	return nullptr;
}